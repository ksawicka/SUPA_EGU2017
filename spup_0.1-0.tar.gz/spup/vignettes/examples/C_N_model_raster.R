C_N_model_raster <- function(OC, TN) {
  OC/TN
}